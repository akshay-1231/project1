to statrt project--> npm init -y
//script-->
//express module
//updation is happening  in package.json

c:\Program Fiels\MongoDB\Server\4.2\bin
then  mongod.exe 
      mongo.exe
there are 2 cmd Fiels


db.users.insert(
    [
    {"name":"akshay","age":22,"place":"jamner"},
    {"name":"ajay","age":23,"place":"jalgaon"},
    {"name":"aj","age":23,"place":"nashik"}
    ]);


    mongoose
    npm i monoose   ---> can see   in package.json

//mysql insertion process

